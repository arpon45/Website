// darkmode.js - Complete Persistent Dark Theme System

/**
 * Initialize theme from localStorage or system preference
 * Applies to all pages automatically
 */
function initializeTheme() {
  // Get saved theme or detect system preference
  const savedTheme = localStorage.getItem('bookinghub-theme');
  const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  
  // Determine which theme to use
  let theme = 'light';
  if (savedTheme) {
    theme = savedTheme;
  } else if (systemPrefersDark) {
    theme = 'dark';
  }
  
  // Apply the theme
  document.documentElement.setAttribute('data-theme', theme);
  updateThemeToggle(theme);
  
  // Set meta theme-color for mobile browsers
  setMetaThemeColor(theme);
}

/**
 * Toggle between light and dark themes
 * Saves preference and updates all elements
 */
function toggleTheme() {
  const currentTheme = document.documentElement.getAttribute('data-theme');
  const newTheme = currentTheme === 'light' ? 'dark' : 'light';
  
  // Apply new theme
  document.documentElement.setAttribute('data-theme', newTheme);
  localStorage.setItem('bookinghub-theme', newTheme);
  updateThemeToggle(newTheme);
  setMetaThemeColor(newTheme);
  
  // Dispatch event for other components to react
  document.dispatchEvent(new CustomEvent('themeChanged', {
    detail: { theme: newTheme }
  }));
}

/**
 * Update the theme toggle button appearance
 */
function updateThemeToggle(theme) {
  const toggleButtons = document.querySelectorAll('.theme-toggle');
  toggleButtons.forEach(button => {
    button.classList.toggle('active', theme === 'dark');
    button.setAttribute('aria-label', theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode');
  });
}

/**
 * Set meta theme-color for mobile browsers
 */
function setMetaThemeColor(theme) {
  const color = theme === 'dark' ? '#1a202c' : '#4361ee';
  let metaTag = document.querySelector('meta[name="theme-color"]');
  
  if (!metaTag) {
    metaTag = document.createElement('meta');
    metaTag.name = 'theme-color';
    document.head.appendChild(metaTag);
  }
  
  metaTag.content = color;
}

/**
 * Watch for system theme changes (if no preference set)
 */
function watchSystemTheme() {
  const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
  mediaQuery.addEventListener('change', (e) => {
    // Only respond if user hasn't set a preference
    if (!localStorage.getItem('bookinghub-theme')) {
      const newTheme = e.matches ? 'dark' : 'light';
      document.documentElement.setAttribute('data-theme', newTheme);
      setMetaThemeColor(newTheme);
    }
  });
}

// Initialize when page loads
document.addEventListener('DOMContentLoaded', () => {
  initializeTheme();
  watchSystemTheme();
  
  // Add event listener to all toggle buttons
  document.querySelectorAll('.theme-toggle').forEach(button => {
    button.addEventListener('click', toggleTheme);
  });
});

// Make functions available globally if needed
window.toggleTheme = toggleTheme;
window.initializeTheme = initializeTheme;